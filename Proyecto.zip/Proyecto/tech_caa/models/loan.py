# -*- coding: utf-8 -*-

from datetime import date, timedelta
from odoo import models, fields, api
from odoo.exceptions import ValidationError


class Loan(models.Model):
    _name = 'tech_caa.loan'
    _description = 'Préstamos de los equipos'

    loan_date = fields.Date(
        string='Fecha de préstamo',
        required=True,
        default=fields.Date.today,
    )

    expected_return_date = fields.Date(
        string='Fecha de devolución prevista',
        required=True,
    )

    status = fields.Selection(
        selection=[
            ('draft', 'Borrador'),
            ('confirmed', 'Confirmado'),
            ('returned', 'Devuelto'),
        ],
        string='Estado',
        default='draft',
        required=True,
    )

    asset_id = fields.Many2one(
        comodel_name='tech_caa.asset',
        string='Equipo',
        required=True,
        ondelete='cascade',
    )

    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Usuario',
        required=True,
    )

    @api.onchange('asset_id', 'loan_date')
    def _onchange_asset_id(self):
        if self.asset_id and self.loan_date:
            max_days = self.asset_id.category_id.max_days_loan
            self.expected_return_date = self.loan_date + timedelta(days=max_days)

    # Integridad del préstamo
    def action_confirm(self):
        for record in self:

            # 1. Validar que el equipo esté disponible
            if record.asset_id.status in ['loaned', 'maintenance', 'retired']:
                raise ValidationError("El equipo no está disponible para préstamo.")

            # 2. Validar morosos
            overdue_loans = self.search([
                ('partner_id', '=', record.partner_id.id),
                ('status', '=', 'confirmed'),
                ('expected_return_date', '<', date.today())
            ])

            if overdue_loans:
                raise ValidationError("El usuario tiene préstamos caducados y no puede realizar nuevos préstamos.")

            # 3. Confirmar préstamo y cambiar estado del equipo
            record.status = 'confirmed'
            record.asset_id.status = 'loaned'


    def action_return(self):
        for record in self:
            record.status = 'returned'
            record.asset_id.status = 'available'