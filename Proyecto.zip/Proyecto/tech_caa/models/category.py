# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Category(models.Model):
    _name = 'tech_caa.category'
    _description = 'Categorías de equipos'

    name = fields.Char(
        string = 'Nombre',
        required = True,
    )
    description = fields.Text(
        string = 'Descripción',
    )

    max_days_loan = fields.Integer(
        string = 'Días máximos de préstamo',
        required = True,
    )