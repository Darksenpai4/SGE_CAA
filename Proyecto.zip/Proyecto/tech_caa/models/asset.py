# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Asset(models.Model):
    _name = 'tech_caa.asset'
    _description = 'Equipos del Centro'

    _sql_constraints = [
        ('serial_number_unique', 'UNIQUE(serial_number)', 'El número de serie debe ser único.'),
    ]

    name = fields.Char(
        string = 'Nombre',
        required = True,
    )
    serial_number = fields.Char(
        string = 'Número de serie',
        required = True,
    )

    purchase_date = fields.Date(
        string = 'Fecha de compra'
    )

    cost = fields.Float(
        string = 'Coste'
    )

    image = fields.Binary(
        string = 'Imagen'
    )

    status = fields.Selection(
        string = 'Estado',
        selection = [
            ('available', 'Disponible'),
            ('loaned', 'Prestado'),
            ('maintenance', 'En mantenimiento'),
            ('retired', 'Baja'),
        ],
        default = 'available',
        required = True,
    )

    category_id = fields.Many2one(
        string = 'Categoría',
        comodel_name = 'tech_caa.category',
        required = True,
    )

    maintenance_ids = fields.One2many(
        string = 'Mantenimientos',
        comodel_name = 'tech_caa.maintenance',
        inverse_name = 'asset_id'
    )