# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Maintenance(models.Model):
    _name = 'tech_caa.maintenance'
    _description = 'Mantenimientos de los equipos'

    description = fields.Text(
        string = 'Descripción de la avería',
        required = True,
    )

    start_date = fields.Date(
        string = 'Fecha de inicio del mantenimiento'
    )

    end_date = fields.Date(
        string = 'Fecha de finalización del mantenimiento'
    )

    cost = fields.Float(
        string = 'Coste'
    )

    asset_id = fields.Many2one(
        string = 'Equipo',
        comodel_name = 'tech_caa.asset',
        required = True,
        ondelete = 'cascade',
    )

    user_id = fields.Many2one(
        string = 'Técnico responsable', 
        comodel_name = 'res.users',
        required = True,
    )

    # Actualizar el estado del equipo a 'maintenance' al crear un mantenimiento
    @api.model
    def create(self, vals):
        record = super(Maintenance, self).create(vals)

        if record.asset_id:
            record.asset_id.status = 'maintenance'

        return record