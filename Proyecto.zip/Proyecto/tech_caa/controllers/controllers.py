# -*- coding: utf-8 -*-
import json
from odoo import http
from odoo.http import request


class TechCaa(http.Controller):

    @http.route('/caa/catalog/assets', auth='public', website=True)
    def index(self, **kw):
        assets = request.env['tech_caa.asset'].sudo().search([])

        return request.render('tech_caa.catalog_assets_template', {
            'assets': assets
        })

    @http.route('/caa/api/assets', type='http', auth='public', methods=['GET'], csrf=False)
    def api_assets(self, **kw):

        status_filter = kw.get('status')  # CAMBIADO

        domain = []
        if status_filter:
            domain.append(('status', '=', status_filter))  # CAMBIADO

        assets = request.env['tech_caa.asset'].sudo().search(domain)

        items = []
        for asset in assets:
            items.append({
                'id': asset.id,
                'name': asset.name,
                'serial_number': asset.serial_number,
                'category': asset.category_id.name if asset.category_id else '',
                'status': asset.status,  # CAMBIADO
            })

        response = {
            'total_items': len(items),
            'items': items
        }

        return request.make_response(
            json.dumps(response),
            headers=[('Content-Type', 'application/json')]
        )