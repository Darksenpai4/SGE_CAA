# -*- coding: utf-8 -*-
{
    'name': "tech_caa",

    'summary': " Gestión de equipos del centro de formación",

    'description': """
        Aplicación para gestionar los equipos del centro de formación
    """,

    'author': "C",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/caa_asset.xml',
        'views/caa_category.xml',
        'views/caa_loan.xml',
        'views/caa_maintenance.xml',
        'views/caa_menu.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'installable': True,
}
